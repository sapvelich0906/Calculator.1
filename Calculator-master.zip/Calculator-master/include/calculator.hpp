double sumary(double a, double b);
double differense(double a, double b);
double multiplication(double a, double b);
double quotient(double a, double b);
double power(double a, int c);
double squareroot(double a);
double absolut(double a);
double roundp(double a);

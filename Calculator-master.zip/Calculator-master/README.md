# Calculator

[![Build Status](https://travis-ci.org/sapvelich0906/Calculator.svg?branch=master)](https://travis-ci.org/sapvelich0906/Calculator)
